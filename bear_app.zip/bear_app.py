import tkinter as tk
from tkinter import messagebox

def on_enter_pressed(event):
    user_input = entry.get()
    if user_input.lower() == "show bear":
        show_bear()
    else:
        messagebox.showinfo("No Bear", "Type 'show bear' to summon the bear!")

def show_bear():
    bear_label = tk.Label(root, text="🐻", font=("Arial", 24), fg="brown", bg="blue")
    bear_label.place(relx=0.5, rely=0.5, anchor="center")

root = tk.Tk()
root.title("Bear Summoner")

# Configure the root window
root.geometry("400x300")
root.configure(bg="blue")

# Text box for input
entry = tk.Entry(root, font=("Arial", 14))
entry.bind("<Return>", on_enter_pressed)
entry.place(relx=0.5, rely=0.9, anchor="center")

root.mainloop()
